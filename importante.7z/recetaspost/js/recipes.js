document.addEventListener('DOMContentLoaded', () => {
    const recipeCardsContainer = document.querySelector('.recipe-cards');
    const urlParams = new URLSearchParams(window.location.search);
    const sharedRecipeId = urlParams.get('share');

    fetch('/recipes.json')
        .then(response => response.json())
        .then(data => {
            data.recipes.forEach(recipe => {
                const card = document.createElement('a');
                card.href = `/recipe.html?id=${recipe.id}`;
                card.className = 'recipe-card';
                if (sharedRecipeId && sharedRecipeId !== recipe.id) {
                    card.style.display = 'none';
                }

                const img = document.createElement('img');
                img.src = recipe.image;
                img.alt = recipe.title;
                img.className = 'recipe-img';

                const infoDiv = document.createElement('div');
                infoDiv.className = 'recipe-info';

                const title = document.createElement('h2');
                title.textContent = recipe.title;

                const source = document.createElement('p');
                source.textContent = `Sacado de: ${recipe.source}`;

                const date = document.createElement('p');
                date.textContent = `Fecha: ${recipe.date}`;

                const actionsDiv = document.createElement('div');
                actionsDiv.className = 'recipe-actions';

                const shareBtn = document.createElement('button');
                shareBtn.className = 'share-btn';
                shareBtn.innerHTML = '<i class="fa-solid fa-share"></i>';
                shareBtn.addEventListener('click', (event) => {
                    event.preventDefault();
                    const shareUrl = `${window.location.origin}${window.location.pathname}?share=${recipe.id}`;
                    navigator.clipboard.writeText(shareUrl).then(() => {
                        alert('Enlace copiado al portapapeles. Comparte esta URL para mostrar solo esta receta.');
                    });
                    showOnlyThisCard(card);
                });

                const favoriteBtn = document.createElement('button');
                favoriteBtn.className = 'favorite-btn';
                favoriteBtn.innerHTML = '<i class="fa-solid fa-bookmark"></i>';
                favoriteBtn.addEventListener('click', (event) => {
                    event.preventDefault();
                    const favorites = JSON.parse(localStorage.getItem('favorites')) || [];
                    
                    if (!favorites.some(fav => fav.title === recipe.title)) {
                        favorites.push({
                            title: recipe.title,
                            img: recipe.image,
                            source: recipe.source,
                            date: recipe.date
                        });
                        localStorage.setItem('favorites', JSON.stringify(favorites));
                        alert('Receta agregada a favoritos');
                    } else {
                        alert('La receta ya está en favoritos');
                    }
                });

                actionsDiv.appendChild(shareBtn);
                actionsDiv.appendChild(favoriteBtn);
                infoDiv.appendChild(title);
                infoDiv.appendChild(source);
                infoDiv.appendChild(date);
                infoDiv.appendChild(actionsDiv);
                card.appendChild(img);
                card.appendChild(infoDiv);
                recipeCardsContainer.appendChild(card);
            });
        })
        .catch(error => console.error('Error al cargar el archivo JSON:', error));

    function showOnlyThisCard(card) {
        const allCards = document.querySelectorAll('.recipe-card');
        allCards.forEach(c => {
            if (c !== card) {
                c.style.display = 'none';
            }
        });
    }

    // Si hay un ID de receta compartida, muestra solo esa tarjeta
    if (sharedRecipeId) {
        const allCards = document.querySelectorAll('.recipe-card');
        allCards.forEach(card => {
            if (card.href.includes(sharedRecipeId)) {
                card.style.display = 'block';
            } else {
                card.style.display = 'none';
            }
        });
    }
});
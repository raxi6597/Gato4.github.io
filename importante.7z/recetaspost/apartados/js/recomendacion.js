document.addEventListener("DOMContentLoaded", function() {
  // Función para obtener el período del día
  function getPeriodOfDay() {
    const hour = new Date().getHours();
    if (hour >= 5 && hour < 12) return 'mañana';
    if (hour >= 12 && hour < 18) return 'tarde';
    if (hour >= 18 || hour < 5) return ['noche', 'madrugada'];
    return 'madrugada';
  }

  // Menú lateral
  const menuToggle = document.getElementById('menu-toggle');
  const menu = document.getElementById('menu');

  menuToggle.addEventListener('click', function(event) {
    menu.classList.toggle('open');
    event.stopPropagation();
  });

  document.addEventListener('click', function(event) {
    if (!menu.contains(event.target) && event.target !== menuToggle && menu.classList.contains('open')) {
      menu.classList.remove('open');
    }
  });

  const recomendacionesDiv = document.getElementById('recomendaciones');

  fetch('/info.json')
    .then(response => response.json())
    .then(data => {
      console.log('Datos cargados:', data);
      const recetas = Object.values(data);
      const currentPeriod = getPeriodOfDay();
      console.log('Período actual:', currentPeriod);

      recetas.forEach(receta => {
        console.log('Receta:', receta);
        // Comprueba si la receta corresponde al período actual
        const shouldDisplay = Array.isArray(currentPeriod) 
          ? (Array.isArray(receta.periodo) 
              ? receta.periodo.some(p => currentPeriod.includes(p))
              : currentPeriod.includes(receta.periodo))
          : (Array.isArray(receta.periodo) 
              ? receta.periodo.includes(currentPeriod)
              : receta.periodo === currentPeriod);

        if (shouldDisplay) {
          const recetaDiv = document.createElement('div');
          recetaDiv.classList.add('receta');

          // Modificamos el enlace para que use el título de la receta
          let enlaceHTML = `<button class="view-recipe-btn" data-title="${receta["title-card"]}">Ver Receta</button>`;

          recetaDiv.innerHTML = `
            <div>
              <h2>${receta["title-card"]}</h2>
              <p>${receta.descripcion}</p>
              <p><strong>Autor:</strong> ${receta.author}</p>
              <p><strong>Fecha:</strong> ${receta.fecha}</p>
              ${enlaceHTML}
            </div>
          `;

          recomendacionesDiv.appendChild(recetaDiv);

          const recommendationsContainer = document.createElement('div');
          recommendationsContainer.classList.add('recommendations-container');
          recommendationsContainer.style.display = 'none';

          let hasRecommendations = false;

          // Verificar recomendacion (string o array)
          if (receta.recomendacion && ((typeof receta.recomendacion === 'string' && receta.recomendacion.trim() !== "") || (Array.isArray(receta.recomendacion) && receta.recomendacion.length > 0 && receta.recomendacion[0].trim() !== ""))) {
            if (typeof receta.recomendacion === 'string') {
              receta.recomendacion = [receta.recomendacion];
            }
            receta.recomendacion.forEach(recomendacion => {
              const recomendacionDiv = document.createElement('div');
              recomendacionDiv.classList.add('recomendacion');
              recomendacionDiv.innerHTML = `<p><strong>Recomendación:</strong> ${recomendacion}</p>`;
              recommendationsContainer.appendChild(recomendacionDiv);
            });
            hasRecommendations = true;
          }

          // Verificar recomendaciones (array)
          if (receta.recomendaciones && Array.isArray(receta.recomendaciones) && receta.recomendaciones.length > 0 && receta.recomendaciones[0].trim() !== "") {
            receta.recomendaciones.forEach(recomendacion => {
              const recomendacionDiv = document.createElement('div');
              recomendacionDiv.classList.add('recomendacion');
              recomendacionDiv.innerHTML = `<p><strong>Recomendación:</strong> ${recomendacion}</p>`;
              recommendationsContainer.appendChild(recomendacionDiv);
            });
            hasRecommendations = true;
          }

          if (hasRecommendations) {
            const showRecommendationsButton = document.createElement('button');
            showRecommendationsButton.classList.add('show-recommendations');
            showRecommendationsButton.textContent = 'Recomendaciones';
            
            showRecommendationsButton.addEventListener('click', function() {
              const isHidden = recommendationsContainer.style.display === 'none';
              recommendationsContainer.style.display = isHidden ? 'block' : 'none';
              showRecommendationsButton.textContent = isHidden ? 'Ocultar Recomendaciones' : 'Recomendaciones';
            });

            recetaDiv.querySelector('div').appendChild(showRecommendationsButton);
            recetaDiv.querySelector('div').appendChild(recommendationsContainer);
          }
        }
      });

      // Añadimos un event listener para todos los botones "Ver Receta"
      document.querySelectorAll('.view-recipe-btn').forEach(button => {
        button.addEventListener('click', function() {
          const recipeTitle = this.getAttribute('data-title');
          fetch('/recipes.json')
            .then(response => response.json())
            .then(recipesData => {
              const recipe = recipesData.recipes.find(r => r.title === recipeTitle);
              if (recipe) {
                // Si encontramos la receta, redirigimos a recipe.html con el ID
                window.location.href = `/recipe.html?id=${recipe.id}`;
              } else {
                console.error('Receta no encontrada:', recipeTitle);
                alert('Lo siento, no se encontró la receta.');
              }
            })
            .catch(error => {
              console.error('Error al cargar recipes.json:', error);
              alert('Hubo un error al cargar la receta. Por favor, intente más tarde.');
            });
        });
      });
    })
    .catch(error => console.error('Error al cargar las recetas:', error));

  const shareButton = document.querySelector(".ShareWeb");

  if (shareButton) {
    shareButton.addEventListener("click", function(event) {
      event.preventDefault();

      if (navigator.share) {
        let shareData = {
          title: document.title,
          text: "¡Descubre esta increíble página!",
          url: window.location.href
        };

        navigator.share(shareData)
          .then(() => console.log("Contenido compartido exitosamente."))
          .catch(error => console.error("Error al compartir:", error));
      } else {
        console.log("La API de compartir no está disponible en este navegador.");
      }
    });
  }
});
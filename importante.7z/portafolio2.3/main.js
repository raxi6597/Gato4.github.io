document.addEventListener('DOMContentLoaded', function() {
  // Smooth scrolling for navigation links
  const navLinks = document.querySelectorAll('nav a');

  navLinks.forEach(link => {
    link.addEventListener('click', function(e) {
      e.preventDefault();
      const targetId = this.getAttribute('href');
      const targetElement = document.querySelector(targetId);
      targetElement.scrollIntoView({ behavior: 'smooth' });
    });
  });

  // Portfolio item hover effect
  const portfolioItems = document.querySelectorAll('.portfolio-item');

  portfolioItems.forEach(item => {
    item.addEventListener('mouseenter', function() {
      this.style.transform = 'scale(1.05)';
      this.style.transition = 'transform 0.3s ease';
    });

    item.addEventListener('mouseleave', function() {
      this.style.transform = 'scale(1)';
    });
  });

  // Form submission
  const contactForm = document.querySelector('form');

  contactForm.addEventListener('submit', function(e) {
    e.preventDefault();

    // Here you would typically send the form data to a server
    // For this example, we'll just log it to the console
    const formData = new FormData(this);
    for (let [key, value] of formData.entries()) {
      console.log(key + ': ' + value);
    }

    alert('Thanks for your message! We\'ll get back to you soon.');
    this.reset();
  });

  // "Show More" button functionality
  const showMoreBtn = document.querySelector('#portfolio .btn');
  let isShowingAll = false;

  showMoreBtn.addEventListener('click', function(e) {
    e.preventDefault();
    const hiddenItems = document.querySelectorAll('.portfolio-item.hidden');

    if (!isShowingAll) {
      hiddenItems.forEach(item => {
        item.classList.remove('hidden');
      });
      this.textContent = 'Show Less';
      isShowingAll = true;
    } else {
      hiddenItems.forEach(item => {
        item.classList.add('hidden');
      });
      this.textContent = 'Show More';
      isShowingAll = false;
    }
  });

  // Lazy loading for portfolio images
  if ('IntersectionObserver' in window) {
    const imgOptions = {};
    const imgObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        const img = entry.target;
        const src = img.getAttribute('data-src');
        img.src = src;
        img.classList.add('fade');
        observer.unobserve(img);
      });
    }, imgOptions);

    const imgs = document.querySelectorAll('img[data-src]');
    imgs.forEach((img) => {
      imgObserver.observe(img);
    });
  }
});
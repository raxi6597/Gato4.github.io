document.addEventListener('DOMContentLoaded', () => {
  const sections = document.querySelectorAll('.section');
  let currentSectionIndex = parseInt(localStorage.getItem('currentSectionIndex')) || 0;
  let currentCourseData = null;
  let currentStepIndex = 0;

  function showSection(index) {
    sections.forEach((section, i) => {
      section.style.display = i === index ? 'block' : 'none';
    });
    localStorage.setItem('currentSectionIndex', index);
  }

  function handleNextButton() {
    const nextButtons = document.querySelectorAll('.next');
    nextButtons.forEach((button) => {
      button.addEventListener('click', () => {
        if (currentSectionIndex === 2) { // Last section (partTree)
          const selectedOption = document.querySelector('input[name="aplicación"]:checked');
          if (selectedOption) {
            const curso = selectedOption.value.toLowerCase();
            localStorage.setItem('selectedCourse', curso);
            loadCourseContent(curso);
          } else {
            alert('Por favor, selecciona una opción.');
          }
        } else if (currentSectionIndex === 3) { // Course content section
          showNextStep();
        } else {
          currentSectionIndex++;
          showSection(currentSectionIndex);
        }
      });
    });
  }

  function loadCourseContent(curso) {
    fetch('cursos.json')
      .then(response => response.json())
      .then(data => {
        currentCourseData = data[curso];
        if (currentCourseData) {
          currentStepIndex = parseInt(localStorage.getItem(`${curso}_stepIndex`)) || 0;
          updateCourseContent();
          currentSectionIndex = 3; // Move to the contenidoCurso section
          showSection(currentSectionIndex);
        } else {
          console.error('Curso no encontrado en el JSON');
          document.getElementById('cursoContenido').style.display = 'none';
        }
      })
      .catch(error => console.error('Error loading cursos.json:', error));
  }

  function updateCourseContent() {
    const cursoContenido = document.getElementById('cursoContenido');
    const cursoTitulo = document.getElementById('cursoTitulo');
    const stepContent = document.getElementById('stepContent');

    cursoTitulo.textContent = `Curso de ${currentCourseData.descripcion}`;

    const currentStep = getCurrentStep();
    if (currentStep) {
      stepContent.innerHTML = `
        <h3>${currentStep.titulo}</h3>
        <p>${currentStep.descripcion}</p>
        <img src="${currentStep.imagen}" alt="${currentStep.titulo}" />
      `;
    } else {
      stepContent.innerHTML = '<p>Curso completado</p>';
      alert('¡Felicidades, ya eres un gran editor de videos!');
    }

    cursoContenido.style.display = 'block';
    saveProgress();
  }

  function getCurrentStep() {
    const steps = [];
    for (const section of currentCourseData.contenido) {
      steps.push(...section.pasos);
    }
    if (currentStepIndex < steps.length) {
      return steps[currentStepIndex];
    }
    return null;
  }

  function showNextStep() {
    currentStepIndex++;
    const totalSteps = currentCourseData.contenido.reduce((total, section) => total + section.pasos.length, 0);
    if (currentStepIndex >= totalSteps) {
      currentStepIndex = totalSteps - 1;
      alert('¡Felicidades, ya eres un gran editor de videos!');
    }
    updateCourseContent();
  }

  function saveProgress() {
    const selectedCourse = localStorage.getItem('selectedCourse');
    if (selectedCourse) {
      localStorage.setItem(`${selectedCourse}_stepIndex`, currentStepIndex);
    }
  }

  function handleVerMasButton() {
    const verMasButton = document.querySelector('.verMas');
    if (verMasButton) {
      verMasButton.addEventListener('click', () => {
        const textExtra = document.querySelector('.textExtra');
        if (textExtra) {
          textExtra.style.display = textExtra.style.display === 'block' ? 'none' : 'block';
        }
      });
    }
  }

  function loadSavedProgress() {
    const savedCourse = localStorage.getItem('selectedCourse');
    if (savedCourse && currentSectionIndex === 3) {
      loadCourseContent(savedCourse);
    } else {
      showSection(currentSectionIndex);
    }
  }

  function setupMenu() {
    const menuNotificaciones = document.getElementById('menu-notificaciones');
    const menuAjustes = document.getElementById('menu-ajustes');
    const ajustesModal = document.getElementById('ajustes-modal');
    const cerrarAjustes = document.getElementById('cerrar-ajustes');
    const borrarProgreso = document.getElementById('borrar-progreso');

    menuNotificaciones.addEventListener('click', (e) => {
      e.preventDefault();
      alert('La función de notificaciones está en desarrollo.');
    });

    menuAjustes.addEventListener('click', (e) => {
      e.preventDefault();
      ajustesModal.style.display = 'block';
    });

    cerrarAjustes.addEventListener('click', () => {
      ajustesModal.style.display = 'none';
    });

    borrarProgreso.addEventListener('click', () => {
      if (confirm('¿Estás seguro de que quieres borrar todo tu progreso? Esta acción no se puede deshacer.')) {
        localStorage.clear();
        currentSectionIndex = 0;
        currentStepIndex = 0;
        currentCourseData = null;
        showSection(currentSectionIndex);
        ajustesModal.style.display = 'none';
        alert('Todo el progreso ha sido borrado.');
      }
    });

    // Cerrar el modal si se hace clic fuera de él
    window.addEventListener('click', (e) => {
      if (e.target === ajustesModal) {
        ajustesModal.style.display = 'none';
      }
    });
  }

  // Abre o cierra el menú al hacer clic en el botón de menú
  document.getElementById('menu-toggle').addEventListener('click', function(event) {
    event.stopPropagation(); // Evita que el clic en el botón cierre el menú inmediatamente
    document.getElementById('main-menu').classList.toggle('show');
  });

  // Cierra el menú si se hace clic fuera del menú
  document.addEventListener('click', function(event) {
    var menu = document.getElementById('main-menu');
    var menuToggle = document.getElementById('menu-toggle');

    if (!menu.contains(event.target) && !menuToggle.contains(event.target)) {
      menu.classList.remove('show');
    }
  });

  // Inicialización
  handleNextButton();
  handleVerMasButton();
  loadSavedProgress();
  setupMenu();
});

// Get the h1 element by its id
const userNameElement = document.getElementById('userName');

// Get the name stored in localStorage
const storedName = localStorage.getItem('myName');

// Check if there's a stored name and update the h1 element content
if (storedName) {
  userNameElement.textContent = storedName;
}
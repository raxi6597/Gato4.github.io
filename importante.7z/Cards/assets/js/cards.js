document.addEventListener("DOMContentLoaded", async () => {
  try {
    const response = await fetch('cards.json');
    const data = await response.json();
    const cardContainer = document.querySelector('.card_container');
    const moreInfoContainer = document.querySelector('.openinfo');
    const body = document.body;

    data.forEach(item => {
      const card = document.createElement('div');
      card.classList.add('card');
      card.setAttribute('data-category', item.categoryVideo.join(' '));
      card.setAttribute('data-title', item.cardTitle);
      card.setAttribute('data-item', JSON.stringify(item));
      card.innerHTML = `
        <img class="card_img" src="${item.imgThumbnail}" alt="Err - The card could not be loaded correctly"><br>
        <h3 class="card_title">${item.cardTitle}</h3>
        
        <div class="card_buttons">
          <span class="card__link" id="moreInfo">Mas info...</span>
        </div>
      `;
      cardContainer.appendChild(card);
      const moreInfoButton = card.querySelector('#moreInfo');
      moreInfoButton.addEventListener('click', () => {
        openMoreInfo(item);
      });
    });

    const closeInfoButton = document.getElementById('closeInfo');
    closeInfoButton.addEventListener('click', () => {
      moreInfoContainer.classList.remove('show');
      body.classList.remove('no_scroll');
    });

    // Añadir evento al botón de compartir
    const shareButton = document.querySelector('.button2 .ri-share-line').parentElement;
    shareButton.addEventListener('click', compartirJuego);

    // Manejar la carga inicial
    handleInitialLoad();

  } catch (error) {
    console.error('Error al cargar el archivo JSON:', error);
  }
});

function openMoreInfo(item) {
  const moreInfoContainer = document.querySelector('.openinfo');
  const body = document.body;
  const cardTitle = document.getElementById('cardTitle');
  const authorCard = document.getElementById('authorCard');
  const duration = document.getElementById('duration');
  const cardVideo = document.getElementById('cardVideo');
  const cardImg = document.getElementById('cardImg');
  const cardDescription = document.getElementById('cardDescription');
  const category = document.getElementById('category');
  const linksContainer = document.querySelector('.buttons_card');

  cardTitle.textContent = item.cardTitle;
  authorCard.textContent = item.authorCard;
  duration.textContent = item.cardVideoDuration;
  cardVideo.href = item.cardLinkVideo;
  cardImg.src = item.imgThumbnail;
  cardDescription.textContent = item.cardDescription;
  category.textContent = item.categoryVideo.join(', ');
  linksContainer.innerHTML = '';
  item.links.forEach((link, index) => {
    const linkButton = document.createElement('a');
    linkButton.href = link;
    linkButton.textContent = `Link ${index + 1}`;
    linkButton.classList.add('button_link');
    linksContainer.appendChild(linkButton);
  });
  moreInfoContainer.classList.add('show');
  body.classList.add('no-scroll');
}

function compartirJuego(e) {
  e.preventDefault();
  var title = document.getElementById('cardTitle').textContent.trim();
  var url = new URL(window.location.href);
  url.hash = "@" + encodeURIComponent(title);
  
  document.querySelectorAll(".card").forEach(function(card) {
    var cardTitle = card.getAttribute("data-title");
    card.style.display = cardTitle === title ? "block" : "none";
  });
  
  alert("¡Comparte esta URL para compartir el juego:\n" + url.href);
  window.history.pushState({}, document.title, url.href);
}

function mostrarTarjetaPorTitulo(title) {
  var cards = document.querySelectorAll(".card");
  var found = false;
  title = normalizeText(title);
  cards.forEach(function(card) {
    var cardTitle = normalizeText(card.getAttribute("data-title"));
    if (cardTitle.includes(title)) {
      card.style.display = "block";
      found = true;
      openMoreInfo(JSON.parse(card.getAttribute('data-item')));
    } else {
      card.style.display = "none";
    }
  });
  return found;
}

function normalizeText(text) {
  return text.trim().toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
}

function handleInitialLoad() {
  var hash = window.location.hash;
  if (hash && hash.startsWith("#@")) {
    var title = decodeURIComponent(hash.substring(2)).replace(/_/g, " ");
    if (!mostrarTarjetaPorTitulo(title)) {
      console.log("No se encontró ninguna tarjeta con ese título.");
    }
  }
}

// Asegurarse de que la tarjeta compartida se mantenga visible incluso después de recargar
window.onload = handleInitialLoad;

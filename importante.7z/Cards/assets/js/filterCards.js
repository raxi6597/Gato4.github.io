function showCards(categoryId) {
  const cards = document.querySelectorAll('.card');

  cards.forEach(card => {
    const cardCategories = card.getAttribute('data-category').split(' ');

    if (categoryId === 'all' || cardCategories.includes(categoryId)) {
      card.style.display = 'block';
    } else {
      card.style.display = 'none';
    }
  });
}

document.addEventListener("DOMContentLoaded", () => {
  document.getElementById('all').addEventListener('click', () => showCards('all'));
  document.getElementById('s1').addEventListener('click', () => showCards('Tutoriales'));
  document.getElementById('s2').addEventListener('click', () => showCards('Videos'));
  document.getElementById('s3').addEventListener('click', () => showCards('Modelos'));
  document.getElementById('s4').addEventListener('click', () => showCards('Cortos'));
  document.getElementById('s5').addEventListener('click', () => showCards('Facil'));
  document.getElementById('s6').addEventListener('click', () => showCards('Otros'));
  document.getElementById('s7').addEventListener('click', () => showCards('Comunidad'));
  document.getElementById('s8').addEventListener('click', () => showCards('Cursos'));
});
window.addEventListener("load", (function() { document.getElementById("loading-spinner").style.display = "none" })), document.addEventListener("DOMContentLoaded", (function() { const e = document.getElementById("menu-toggle"),
    n = document.getElementById("menu");
  e.addEventListener("click", (function() { n.classList.toggle("menu-visible") })), document.addEventListener("click", (function(e) { const t = e.target,
      s = t.closest("#menu"),
      i = t.closest("#menu-toggle");
    s || i || !n.classList.contains("menu-visible") || n.classList.remove("menu-visible") })) }));
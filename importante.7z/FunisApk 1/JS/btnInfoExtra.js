document.addEventListener("DOMContentLoaded", function() {
    // Añadir alt text a las imágenes dentro de las tarjetas
    document.querySelectorAll(".card").forEach((e) => {
        const t = e.querySelector(".title");
        if (t) {
            const n = t.textContent.trim();
            if (n) {
                e.querySelectorAll("img").forEach((e) => {
                    e.alt = `Logo De ${n}`;
                });
            }
        }
    });

    // Añadir evento click a las tarjetas
    var cards = document.querySelectorAll(".card");
    cards.forEach((e) => {
        e.addEventListener("click", function() {
            var t = e.querySelector("#Extra_Info");
            if (t) {
                var appName = e.getAttribute("data-title"); // Obtener el nombre de la aplicación desde data-title

                // Almacenar información en localStorage
                localStorage.setItem("appName", appName);
                var extraInfo = t.innerHTML;
                localStorage.setItem("extraInfo", extraInfo);

                // Obtener y almacenar la empresa también como "empresa" en localStorage
                var company = e.querySelector(".Company");
                if (company) {
                    var empresa = company.textContent.trim();
                    localStorage.setItem("empresa", empresa);
                }

                // Actualizar el hash de la URL
                var newURL = "/newpage.html#" + encodeURIComponent(appName);

                // Redirigir a la nueva página HTML con el hash
                window.location.href = newURL;
            }
        });
    });
});

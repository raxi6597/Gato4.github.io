<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre'];
    $email = $_POST['email'];
    $mensaje = $_POST['mensaje'];
    
    // Dirección de correo donde recibirás el mensaje
    $destinatario = 'samuelaguilare0@gmail.com';
    
    // Asunto del mensaje
    $asunto = 'Mensaje de contacto desde el sitio web';
    
    // Construir el cuerpo del mensaje
    $cuerpoMensaje = "Nombre: $nombre\n";
    $cuerpoMensaje .= "Email: $email\n\n";
    $cuerpoMensaje .= "Mensaje:\n$mensaje";
    
    // Cabeceras del correo
    $cabeceras = "From: $nombre <$email>\r\n";
    $cabeceras .= "Reply-To: $email\r\n";
    
    // Enviar el correo
    mail($destinatario, $asunto, $cuerpoMensaje, $cabeceras);
    
    // Redireccionar después de enviar el formulario
    header('Location: gracias.html');
} else {
    // Si no es un método POST, redireccionar a una página de error o mostrar un mensaje
    echo 'Error: Método no permitido';
}
?>

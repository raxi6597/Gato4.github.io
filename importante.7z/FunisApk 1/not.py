import discord
from discord.ext import commands
import requests
from bs4 import BeautifulSoup
import re
import asyncio

intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix='!', intents=intents)

@bot.event
async def on_ready():
    print(f'{bot.user} ha iniciado sesión en Discord!')

@bot.command(name='appinfo')
async def get_app_info(ctx, *, app_name: str):
    await ctx.send(f"Buscando información para {app_name}...")
    app_info = await bot.loop.run_in_executor(None, buscar_app_info, app_name)
    
    if app_info:
        embed = discord.Embed(title=app_info['nombre'], description=app_info['descripcion'], color=0x00ff00)
        embed.set_thumbnail(url=app_info['foto_url'])
        embed.add_field(name="Versión", value=app_info['version'], inline=True)
        embed.add_field(name="Tags", value=", ".join(app_info['tags']), inline=True)
        embed.add_field(name="Descarga", value=app_info['download_url'], inline=False)
        
        await ctx.send(embed=embed)
    else:
        await ctx.send(f"No se pudo encontrar información para la aplicación: {app_name}")

def buscar_app_info(app_name):
    search_url = f"https://apkgstore.com/?s={app_name.replace(' ', '+')}"
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
    }
    
    try:
        response = requests.get(search_url, headers=headers)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, 'html.parser')
        
        app_link = soup.find('h2', class_='post-title').find('a')['href']
        
        app_response = requests.get(app_link, headers=headers)
        app_response.raise_for_status()
        app_soup = BeautifulSoup(app_response.text, 'html.parser')
        
        nombre = app_soup.find('h1', class_='post-title').text.strip()
        descripcion = app_soup.find('div', class_='post-content').find('p').text.strip()
        foto_url = app_soup.find('div', class_='post-thumbnail').find('img')['src']
        version = re.search(r'Version:\s*([\d.]+)', app_soup.text).group(1)
        tags = [tag.text for tag in app_soup.find_all('a', rel='tag')]
        
        download_url = ''
        for link in app_soup.find_all('a', href=True):
            if 'mediafire.com' in link['href']:
                download_url = link['href']
                break
        
        return {
            'nombre': nombre,
            'descripcion': descripcion,
            'foto_url': foto_url,
            'version': version,
            'tags': tags,
            'download_url': download_url
        }
    except Exception as e:
        print(f"Error al buscar la información de la app: {str(e)}")
        return None

# Reemplace 'TOKEN' con el token real de su bot
bot.run('7dc676309bfbbb8f1101941cbffc2df11abf4dfea5d22bce36ec736efb6885bc')
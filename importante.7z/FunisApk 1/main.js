var addedCategories = [],
  cards = document.querySelectorAll(".card"),
  scrollPosition = 0;

function addCategoryToMenu(e) { if (!addedCategories.includes(e)) { addedCategories.push(e); var t = document.querySelector(".menu-lateral ul:nth-child(2)"),
      o = document.createElement("li"),
      r = document.createElement("a");
    r.textContent = e, r.href = "#", o.appendChild(r), t.appendChild(o), localStorage.setItem("addedCategories", JSON.stringify(addedCategories)), r.addEventListener("click", function(t) { t.preventDefault(), filterCardsByCategory(e) }) } }

function filterCardsByCategory(e) { cards.forEach(function(t) { var o = t.querySelector(".category").textContent,
      r = null !== t.querySelector("#miDiv.tag.original");
    t.style.display = "Todas" === e || o === e || "Apps Originales" === e && r ? "block" : "none" }), localStorage.setItem("selectedCategory", e), updateCardCounter() }

function updateCardCounter() { var e = 0;
  cards.forEach(function(t) { "block" === window.getComputedStyle(t).getPropertyValue("display") && e++ }); var t = document.getElementById("contadorTarjetas");
  t && (t.textContent = "TOTAL DE APPS: " + e) }

function actualizarContenido(e) { e.forEach(e => { if ("attributes" === e.type) { var t = e.target,
        o = t.className;
      o.includes("newocul") ? (console.log("Ocultando div"), t.style.display = "none") : o.includes("new") ? (t.innerHTML = "NEW", t.style.display = "") : o.includes("act") ? (t.innerHTML = "ACTUALIZADA", t.style.display = "") : o.includes("mod") ? (t.innerHTML = "MOD", t.style.display = "") : (t.innerHTML = "ORIGINAL", t.style.display = "") } }) } document.addEventListener("DOMContentLoaded", function() { filterCardsByCategory(localStorage.getItem("selectedCategory") || "Todas"), cards.forEach(function(e) { addCategoryToMenu(e.querySelector(".category").textContent) }), addCategoryToMenu("Apps Originales"), document.querySelectorAll(".menu-lateral ul:nth-child(2) li a").forEach(function(e) { e.addEventListener("click", function(e) { e.preventDefault(), filterCardsByCategory(this.textContent) }) }), document.querySelector(".show-all-apps").addEventListener("click", function(e) { e.preventDefault(), filterCardsByCategory("Todas") }), cards.forEach(function(e) { e.style.display = "block" }), document.getElementById("loading-spinner").style.display = "block", window.addEventListener("load", function() { document.getElementById("loading-spinner").style.display = "none" }); let e = document.getElementById("menu-toggle"),
    t = document.getElementById("menu");
  e.addEventListener("click", function() { t.classList.toggle("menu-visible") }), document.addEventListener("click", function(e) { let o = e.target,
      r = o.closest("#menu"),
      n = o.closest("#menu-toggle");
    r || n || !t.classList.contains("menu-visible") || t.classList.remove("menu-visible") }); var o = document.querySelector('meta[name="author"]').getAttribute("content"),
    r = document.getElementById("authorName");
  o && (r.textContent = o); var n = document.querySelector('meta[name="keywords"]'),
    l = [];
  n && (l = n.getAttribute("content").split(",")), document.querySelectorAll(".card .title").forEach(function(e) { var t = e.closest(".card").getAttribute("data-fecha-hora"); if (!t || t && new Date >= new Date(t)) { var o = e.textContent.trim();
      l.includes(o) || l.push(o) } }); var a = document.getElementById("tags");
  a.innerHTML = "", l.forEach(function(e) { var t = document.createElement("span");
    t.textContent = e.trim(), a.appendChild(t) }), document.querySelectorAll(".dropdown .dropbtn, .categ").forEach(function(e) { e.addEventListener("click", function(e) { e.preventDefault() }) }), document.getElementById("default").addEventListener("click", function(e) { e.preventDefault(), scrollPosition = window.scrollY, document.body.style.backgroundColor = "", document.body.style.color = "", document.querySelectorAll(".card, .tags, footer, .container, header, .menu-lateral, .dropdown-content, .compartir, .descripcion, #search-button").forEach(function(e) { e.style.backgroundColor = "", e.style.color = "" }), document.querySelector("header").style.backgroundImage = "", document.querySelector(".logo img").src = "https://i.ibb.co/VYTyTZt/Picsart-24-01-19-19-06-23-334.png", window.scrollTo(0, scrollPosition) }), document.getElementById("classic").addEventListener("click", function(e) { e.preventDefault(), scrollPosition = window.scrollY, document.body.style.backgroundColor = "#121212", document.body.style.color = "#000"; var t = document.querySelectorAll("header, footer, .tags, .container, .menu-lateral, .dropdown-content");
    t.forEach(function(e) { e.style.backgroundColor = "#121212", e.style.color = "#fff" }), document.querySelector("header").style.backgroundImage = "none", document.querySelector(".logo img").src = "https://i.ibb.co/VYTyTZt/Picsart-24-01-19-19-06-23-334.png", (t = document.querySelectorAll(".card, .compartir, .descripcion, .popup")).forEach(function(e) { e.style.backgroundColor = e.classList.contains("card") ? "#fff" : "#ddd", e.style.color = "#000" }), window.scrollTo(0, scrollPosition) }), document.getElementById("blue").addEventListener("click", function(e) { e.preventDefault(), scrollPosition = window.scrollY, document.body.style.backgroundColor = "#0a0f25", document.body.style.color = "#ffffff", document.querySelectorAll(".card, .tags, footer, .container, header, .menu-lateral, .dropdown-content, .compartir, .descripcion, #search-button").forEach(function(e) { e.style.backgroundColor = "footer" === e.tagName.toLowerCase() ? "#001f7e" : "#0a0f25", e.style.color = "#ffffff" }), document.querySelector("header").style.backgroundImage = "none", document.querySelector(".logo img").src = "https://i.ibb.co/JsHTSNC/Picsart-24-04-14-16-34-43-115.png", window.scrollTo(0, scrollPosition) }), document.getElementById("green").addEventListener("click", function(e) { e.preventDefault(), scrollPosition = window.scrollY, document.body.style.backgroundColor = "#002b2b", document.body.style.color = "#ffffff", document.querySelectorAll(".card, .tags, footer, .container, header, .menu-lateral, .dropdown-content, .compartir, .descripcion, #search-button").forEach(function(e) { e.style.backgroundColor = "footer" === e.tagName.toLowerCase() ? "#00ff00" : "#002b2b", e.style.color = "footer" === e.tagName.toLowerCase() ? "#000000" : "#ffffff" }), document.querySelector("header").style.backgroundImage = "none", document.querySelector(".logo img").src = "https://i.ibb.co/dDv78W1/Picsart-24-04-14-16-46-52-875.png", window.scrollTo(0, scrollPosition) }), document.getElementById("neon-purple").addEventListener("click", function(e) { e.preventDefault(), scrollPosition = window.scrollY, document.body.style.backgroundColor = "#2E054A", document.body.style.color = "#fff", document.querySelectorAll(".card, .tags, footer, .container, header, .menu-lateral, .dropdown-content, .compartir, .descripcion, #search-button, .popup").forEach(function(e) { e.style.backgroundColor = e.classList.contains("card") ? "#7209B7" : "footer" === e.tagName.toLowerCase() ? "#2E054A" : "#F72585", e.style.color = "#fff" }), document.querySelector("header").style.backgroundImage = "none", document.querySelector(".logo img").src = "https://i.ibb.co/dDv78W1/Picsart-24-04-14-16-46-52-875.png", window.scrollTo(0, scrollPosition) }) }), document.querySelector(".show-all-apps").addEventListener("click", function(e) { e.preventDefault(), filterCardsByCategory("Todas") });
var divs = document.querySelectorAll("#miDiv, #miNew");

function actualizarContenidoContainer(e) { e.forEach(e => { "childList" === e.type && e.addedNodes.forEach(e => { 1 !== e.nodeType || "miNew" !== e.id && "miDiv" !== e.id || (console.log(`Nuevo nodo agregado con ID ${e.id}`), new MutationObserver(actualizarContenido).observe(e, { attributes: !0 }), actualizarContenido([{ target: e, type: "attributes" }])) }) }) } divs.forEach(e => { new MutationObserver(actualizarContenido).observe(e, { attributes: !0 }), actualizarContenido([{ target: e, type: "attributes" }]) }), document.addEventListener("DOMContentLoaded", function() { let e = document.querySelector(".ShareWeb");
  e && e.addEventListener("click", function(e) { if (e.preventDefault(), navigator.share) { let t = { title: document.title, text: "\xa1Descubre esta incre\xedble p\xe1gina!", url: window.location.href };
      navigator.share(t).then(() => console.log("Contenido compartido exitosamente.")).catch(e => console.error("Error al compartir:", e)) } else console.log("La API de compartir no est\xe1 disponible en este navegador.") }) });
var container = document.querySelector(".content"),
  containerObserver = new MutationObserver(actualizarContenidoContainer);

function scrollFunction() { var e = document.getElementById("scroll-btn");
  e ? window.scrollY > 0 ? e.innerHTML = "↑" : e.innerHTML = "↓" : console.error("Elemento con ID 'scroll-btn' no encontrado.") }

function scrollToPosition() { window.scrollY > 0 ? window.scrollTo({ top: 0, behavior: "smooth" }) : window.scrollTo({ top: document.body.scrollHeight, behavior: "smooth" }) }

function shuffleArray(e) { for (let t = e.length - 1; t > 0; t--) { let o = Math.floor(Math.random() * (t + 1));
    [e[t], e[o]] = [e[o], e[t]] } }

function arrangeCards() { var e = new Date().getDate(),
    t = [],
    o = [],
    r = [];
  cards.forEach(e => { var n = e.querySelector("#miNew.tag.new"),
      l = e.querySelector("#miNew.tag.act");
    n ? t.push(e) : l ? o.push(e) : r.push(e) }), e % 2 == 0 ? r.sort((e, t) => e.querySelector(".title").textContent.localeCompare(t.querySelector(".title").textContent)) : shuffleArray(r); var n = document.getElementById("new-section"),
    l = document.getElementById("updated-section");
  n.innerHTML = "<h2>Nuevas</h2>", l.innerHTML = "<h2>Actualizadas</h2>", t.forEach(e => n.appendChild(e)), o.forEach(e => l.appendChild(e)), r.forEach(e => cardsContainer.appendChild(e)), 0 === t.length && (n.style.display = "none"), 0 === o.length && (l.style.display = "none") } containerObserver.observe(container, { childList: !0, subtree: !0 }), window.onscroll = function() { scrollFunction() }, document.addEventListener("DOMContentLoaded", function() { arrangeCards() });